const express = require('express');
const cors = require('cors');
const { 
  scrapeHome, 
  scrapeAnimeDetail, 
  scrapeAnimeWatch, 
  scrapeMovieWatch, 
  scrapeSeriesDetail, 
  scrapeSeriesWatch, 
  scrapeGenre, 
  scrapeLatestAnime, 
  scrapeFilterAnime, 
  scrapeMovieList,
  scrapeSearch,
  scrapeDonghuaList,
  scrapeOthersList,
  scrapeAlphabeticalList
} = require('./winbu');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.get('/', (req, res) => {
  res.json({
    message: 'Winbu Scraper API is running',
    endpoints: {
      home: '/api/home',
      search: '/api/search?q=query&page=1',
      detail_anime: '/api/detail/anime/:slug (Include Donghua)',
      detail_series: '/api/detail/series/:slug',
      genre: '/api/genre/:slug/page/:page',
      latest_anime: '/api/anime-terbaru/page/:page',
      donghua_list: '/api/donghua/page/:page',
      others_list: '/api/others/page/:page',
      film_list: '/api/film/page/:page',
      alphabetical_list: '/api/alphabetical-list',
      search_advanced: '/api/search/advanced?title=&status=&type=&order=&genre[]=action&page=1',
      watch_anime: '/api/watch/anime/:slug (Include Donghua)',
      watch_series: '/api/watch/series/:slug',
      watch_film: '/api/watch/film/:slug'
    }
  });
});

app.get('/api/home', async (req, res) => {
  try {
    const data = await scrapeHome();
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/search', async (req, res) => {
  const { q, page = 1 } = req.query;
  if (!q) return res.status(400).json({ status: false, message: 'Query parameter "q" is required' });
  try {
    const data = await scrapeSearch(q, page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/detail/anime/:slug', async (req, res) => {
  const { slug } = req.params;
  try {
    const data = await scrapeAnimeDetail(slug);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/detail/series/:slug', async (req, res) => {
  const { slug } = req.params;
  try {
    const data = await scrapeSeriesDetail(slug);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/genre/:slug/page/:page', async (req, res) => {
  const { slug, page } = req.params;
  try {
    const data = await scrapeGenre(slug, page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/anime-terbaru/page/:page', async (req, res) => {
  const { page } = req.params;
  try {
    const data = await scrapeLatestAnime(page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/donghua/page/:page', async (req, res) => {
  const { page } = req.params;
  try {
    const data = await scrapeDonghuaList(page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/others/page/:page', async (req, res) => {
  const { page } = req.params;
  try {
    const data = await scrapeOthersList(page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/film/page/:page', async (req, res) => {
  const { page } = req.params;
  try {
    const data = await scrapeMovieList(page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/alphabetical-list', async (req, res) => {
  try {
    const data = await scrapeAlphabeticalList();
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/search/advanced', async (req, res) => {
  const { page = 1, ...query } = req.query;
  try {
    const data = await scrapeFilterAnime(query, page);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/watch/anime/:slug', async (req, res) => {
  const { slug } = req.params;
  try {
    const data = await scrapeAnimeWatch(slug);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/watch/series/:slug', async (req, res) => {
  const { slug } = req.params;
  try {
    const data = await scrapeSeriesWatch(slug);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.get('/api/watch/film/:slug', async (req, res) => {
  const { slug } = req.params;
  try {
    const data = await scrapeMovieWatch(slug);
    res.status(200).json({ status: true, data });
  } catch (error) {
    res.status(500).json({ status: false, message: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});