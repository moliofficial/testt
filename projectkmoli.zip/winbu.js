const axios = require('axios');
const cheerio = require('cheerio');
const qs = require('qs');

const BASE_URL = 'https://winbu.net';

/**
 * Mendapatkan header yang meniru browser asli secara akurat.
 * Digunakan untuk menghindari deteksi bot dan pemblokiran (WAF/Cloudflare).
 */
const getHeaders = (referer = BASE_URL) => {
  return {
    'authority': 'winbu.net',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language': 'en-US,en;q=0.9,id;q=0.8',
    'cache-control': 'max-age=0',
    'referer': referer,
    'sec-ch-ua': '"Chromium";v="123", "Not:A-Brand";v="8", "Google Chrome";v="123"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
  };
};

// Normalisasi rating: ganti koma ke titik, rating 0 jadi N/A
const normalizeRating = (raw) => {
  if (!raw) return 'N/A';
  const cleaned = raw.replace(',', '.').trim();
  const num = parseFloat(cleaned);
  if (isNaN(num) || num === 0) return 'N/A';
  return String(num);
};

// Helper: parse item list terbaru
const parseLatestItem = ($, el) => {
  const $el = $(el);
  const mask = $el.find('a.ml-mask');
  const link = mask.attr('href') || '';
  const title = mask.attr('title') || $el.find('.judul').text().trim();
  const thumb = $el.find('img.mli-thumb').attr('src') || $el.find('img.mli-thumb').attr('data-original') || '';
  const infoHidden = $el.find('i.info-hidden');
  const dataRating = infoHidden.attr('data-rating') || '';
  const dataEpisode = infoHidden.attr('data-episode') || '';
  const starRaw = $el.find('.mli-mvi').filter((_, mvi) => $(mvi).find('.fa-star').length > 0).text().trim();
  const rating = (dataRating && dataRating !== '0') ? normalizeRating(dataRating) : normalizeRating(starRaw);
  const episodeText = $el.find('.mli-episode').text().trim();
  const episode = (dataEpisode && dataEpisode !== '0') ? `Episode ${dataEpisode}` : (episodeText || 'N/A');
  const views = $el.find('.mli-mvi').filter((_, mvi) => $(mvi).find('.fa-eye').length > 0).text().trim() || '0';
  const uploadTime = $el.find('.mli-waktu').text().replace(/[\r\n\t]/g, '').trim() || 'N/A';
  const quality = $el.find('.mli-quality').text().trim() || null;
  const topRankRaw = $el.find('.mli-topten b').text().trim();
  const topRank = topRankRaw ? parseInt(topRankRaw, 10) : null;

  let type = 'unknown';
  if (link.includes('/anime/')) type = 'anime';
  else if (link.includes('/film/')) type = 'film';
  else if (link.includes('/series/')) type = 'series';

  return { title, type, link, slug: link.split('/').filter(Boolean).pop(), thumb, episode, rating, views, uploadTime, quality, topRank };
};

// Helper: parse metadata dari .m-info
const parseMInfo = ($, mInfo) => {
  let rating = 'N/A', date = 'N/A', credit = 'N/A', encode = 'N/A', quality = 'N/A', country = 'N/A', genres = [];
  mInfo.find('.mli-mvi').each((_, el) => {
    const text = $(el).text().trim();
    if (text.includes('Rating :')) rating = text.replace('Rating :', '').split('/')[0].trim();
    else if ($(el).find('.fa-calendar').length > 0) date = text;
    else if (text.includes('Credit :')) credit = text.replace('Credit :', '').trim();
    else if (text.includes('Encode :')) encode = text.replace('Encode :', '').trim();
    else if (text.includes('Kualitas :')) quality = text.replace('Kualitas :', '').trim();
    else if (text.includes('Negara :')) country = $(el).find('a').text().trim();
    else if (text.includes('Genre :')) {
      $(el).find('a').each((_, a) => { genres.push({ name: $(a).text().trim(), link: $(a).attr('href') }); });
    }
  });
  return { rating, date, credit, encode, quality, country, genres };
};

// Helper: parse pagination
const parsePagination = ($) => {
  const pagination = [];
  $('.pagination li').each((_, el) => {
    const $a = $(el).find('a'), pageText = $(el).text().trim() || $a.text().trim(), pageLink = $a.attr('href') || '';
    if (pageText) { pagination.push({ text: pageText, link: pageLink, page: pageLink ? pageLink.split('/').filter(Boolean).pop() : null, isActive: $(el).hasClass('active') }); }
  });
  return pagination;
};

async function scrapeHome() {
  try {
    const { data } = await axios.get(BASE_URL, { headers: getHeaders() });
    const $ = cheerio.load(data);
    const topSeries = [], topMovies = [], latestAnime = [], latestMovies = [], latestSeries = [], tvShows = [];
    const parseSliderItem = (el) => {
      const $el = $(el), mask = $el.find('a.ml-mask'), link = mask.attr('href') || '', title = mask.attr('title') || $el.find('.judul').text().trim(), thumb = $el.find('img.mli-thumb').attr('src') || $el.find('img.mli-thumb').attr('data-original') || '', rankRaw = $el.find('.mli-topten b').text().replace('#', '').trim(), rank = rankRaw ? parseInt(rankRaw, 10) : null, ratingRaw = $el.find('.mli-mvi').filter((_, mvi) => $(mvi).find('.fa-star').length > 0).text().trim(), rating = normalizeRating(ratingRaw);
      let type = 'unknown';
      if (link.includes('/anime/')) type = 'anime';
      else if (link.includes('/film/')) type = 'film';
      else if (link.includes('/series/')) type = 'series';
      return { rank, type, title, link, slug: link.split('/').filter(Boolean).pop(), thumb, rating };
    };
    $('.movies-list-wrap.mlw-category').each((_, section) => {
      const sectionTitle = $(section).find('.list-title h2').text().trim();
      if (sectionTitle.includes('Top 10 Series')) $(section).find('.ml-slider-manual .ml-item').each((_, el) => { topSeries.push(parseSliderItem(el)); });
      else if (sectionTitle.includes('Top 10 Film')) $(section).find('.ml-slider-manual .ml-item').each((_, el) => { topMovies.push(parseSliderItem(el)); });
    });
    $('.movies-list-wrap').each((_, section) => {
      const sectionTitle = $(section).find('.list-title h2').text().trim();
      const isAnime = sectionTitle.includes('Anime Donghua Terbaru'), isMovie = sectionTitle.includes('Film Terbaru'), isSeries = sectionTitle.includes('Jepang Korea China Barat'), isTvShow = sectionTitle.includes('TV Show');
      if (!isAnime && !isMovie && !isSeries && !isTvShow) return;
      $(section).find('.ml-item').each((_, el) => {
        const item = parseLatestItem($, el);
        if (isAnime) { const { quality, ...animeItem } = item; latestAnime.push(animeItem); }
        else if (isMovie) { const { topRank, episode, ...movieItem } = item; latestMovies.push(movieItem); }
        else if (isSeries) { const { quality, ...seriesItem } = item; latestSeries.push(seriesItem); }
        else if (isTvShow) { const { quality, ...tvItem } = item; tvShows.push(tvItem); }
      });
    });
    return { topSeries, topMovies, latestAnime, latestMovies, latestSeries, tvShows };
  } catch (error) { throw error; }
}

async function scrapeAnimeDetail(slug) {
  try {
    const url = `${BASE_URL}/anime/${slug}/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), mInfo = $('.m-info'), title = $('.list-title').first().find('h2').text().replace(/.*?\s/, '').trim(), thumb = mInfo.find('img.mli-thumb').attr('src') || '', followedCount = $('#follows').text().replace('Followed', '').trim(), metadata = parseMInfo($, mInfo), sinopsis = $('.mli-desc').text().trim(), episodes = [];
    $('.tvseason .les-content a').each((_, el) => { episodes.push({ title: $(el).text().trim(), link: $(el).attr('href'), slug: $(el).attr('href').split('/').filter(Boolean).pop() }); });
    let trailerUrl = $('.youtube_id iframe').attr('src') || '';
    if (trailerUrl.startsWith('//')) trailerUrl = 'https:' + trailerUrl;
    const youtubeId = trailerUrl ? trailerUrl.split('/').pop().split('?')[0] : '', recommendations = [];
    $('.rekom .ml-item-rekom').each((_, el) => {
      const $el = $(el), mask = $el.find('a.ml-mask'), recLink = mask.attr('href') || '', recTitle = mask.attr('title') || $el.find('.judul').text().trim(), recThumb = $el.find('img.mli-thumb').attr('src') || '', recRating = $el.find('.mli-mvi').text().trim();
      recommendations.push({ title: recTitle, link: recLink, slug: recLink.split('/').filter(Boolean).pop(), thumb: recThumb, rating: normalizeRating(recRating) });
    });
    return { title, thumb, followedCount, ...metadata, sinopsis, trailer: youtubeId ? `https://www.youtube.com/watch?v=${youtubeId}` : null, episodes, recommendations };
  } catch (error) { throw error; }
}

async function scrapeAnimeWatch(slug) {
  try {
    const url = `${BASE_URL}/${slug}/`;
    const { data } = await axios.get(url, { headers: getHeaders(`${BASE_URL}/anime/${slug.split('-episode')[0]}/`) });
    const $ = cheerio.load(data), title = $('.list-title').first().find('h2').text().replace(/.*?\s/, '').trim();
    let streamUrl = $('.pframe iframe').attr('src') || $('.movieplay iframe').attr('src') || $('#gsmtplay iframe').attr('src') || $('.tab-content iframe').attr('src') || '';
    if (!streamUrl) { $('iframe').each((_, el) => { const src = $(el).attr('src'); if (src && (src.includes('blogger.com') || src.includes('ok.ru') || src.includes('google.com') || src.includes('vidhide'))) { streamUrl = src; return false; } }); }
    const streamOptions = [];
    $('.player-modes .dropdown').each((_, drop) => {
      const resolution = $(drop).find('button').text().trim(), servers = [];
      $(drop).find('.dropdown-item .east_player_option').each((_, opt) => { servers.push({ name: $(opt).text().trim(), post: $(opt).attr('data-post'), nume: $(opt).attr('data-nume'), type: $(opt).attr('data-type') }); });
      if (resolution && servers.length > 0) streamOptions.push({ resolution, servers });
    });
    if (!streamUrl && streamOptions.length > 0) {
      const firstServer = streamOptions[0].servers[0];
      if (firstServer) {
        try {
          const { data: ajaxData } = await axios.post(`${BASE_URL}/wp-admin/admin-ajax.php`, qs.stringify({ action: 'player_ajax', post: firstServer.post, nume: firstServer.nume, type: firstServer.type }), { headers: { ...getHeaders(url), 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'x-requested-with': 'XMLHttpRequest' } });
          const $ajax = cheerio.load(ajaxData); streamUrl = $ajax('iframe').attr('src') || '';
        } catch (e) {}
      }
    }
    const downloadLinks = [];
    $('.download-eps ul li').each((_, li) => {
      const resolution = $(li).find('strong').text().trim(), links = [];
      $(li).find('span a').each((_, a) => { links.push({ platform: $(a).text().trim(), link: $(a).attr('href') }); });
      if (resolution && links.length > 0) downloadLinks.push({ resolution, links });
    });
    const prevEpisode = $('.naveps .nvs').first().find('a').attr('href'), nextEpisode = $('.naveps .nvs.rght').find('a').attr('href'), allEpisodes = $('.naveps .nvsc a').attr('href');
    const episodeList = [];
    $('.dropdownEpisodeList .dropdown-menu .dropdown-item a').each((_, a) => { episodeList.push({ title: $(a).text().trim(), link: $(a).attr('href'), slug: $(a).attr('href').split('/').filter(Boolean).pop(), isActive: $(a).hasClass('active') }); });
    const mInfo = $('.m-info'), thumb = mInfo.find('img.mli-thumb').attr('src') || '', animeTitle = mInfo.find('.judul').text().trim(), followedCount = mInfo.find('#follows').text().replace('Followed', '').trim(), metadata = parseMInfo($, mInfo), sinopsis = mInfo.find('.mli-desc').text().trim();
    return { title, animeTitle, thumb, followedCount, ...metadata, sinopsis, streamUrl: streamUrl.startsWith('//') ? 'https:' + streamUrl : streamUrl, streamOptions, downloadLinks, navigation: { prev: prevEpisode && prevEpisode !== '#' ? prevEpisode.split('/').filter(Boolean).pop() : null, next: nextEpisode && nextEpisode !== '#' ? nextEpisode.split('/').filter(Boolean).pop() : null, all: allEpisodes ? allEpisodes.split('/').filter(Boolean).pop() : null }, episodeList };
  } catch (error) { throw error; }
}

async function scrapeMovieWatch(slug) {
  try {
    const url = `${BASE_URL}/film/${slug}/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title').first().find('h2').text().replace(/.*?\s/, '').trim();
    let streamUrl = $('.pframe iframe').attr('src') || $('.movieplay iframe').attr('src') || $('#gsmtplay iframe').attr('src') || '';
    if (!streamUrl) { $('iframe').each((_, el) => { const src = $(el).attr('src'); if (src && (src.includes('blogger.com') || src.includes('ok.ru') || src.includes('google.com') || src.includes('vidhide'))) { streamUrl = src; return false; } }); }
    const streamOptions = [];
    $('.player-modes .dropdown').each((_, drop) => {
      const label = $(drop).find('button').text().trim(), servers = [];
      $(drop).find('.dropdown-item .east_player_option').each((_, opt) => { servers.push({ name: $(opt).text().trim(), post: $(opt).attr('data-post'), nume: $(opt).attr('data-nume'), type: $(opt).attr('data-type') }); });
      if (servers.length > 0) streamOptions.push({ label, servers });
    });
    if (!streamUrl && streamOptions.length > 0) {
      const firstServer = streamOptions[0].servers[0];
      if (firstServer) {
        try {
          const { data: ajaxData } = await axios.post(`${BASE_URL}/wp-admin/admin-ajax.php`, qs.stringify({ action: 'player_ajax', post: firstServer.post, nume: firstServer.nume, type: firstServer.type }), { headers: { ...getHeaders(url), 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'x-requested-with': 'XMLHttpRequest' } });
          const $ajax = cheerio.load(ajaxData); streamUrl = $ajax('iframe').attr('src') || '';
        } catch (e) {}
      }
    }
    const downloadLinks = [];
    $('.download-eps ul li').each((_, li) => {
      const resolution = $(li).find('strong').text().trim(), links = [];
      $(li).find('span a').each((_, a) => { links.push({ platform: $(a).text().trim(), link: $(a).attr('href') }); });
      if (resolution && links.length > 0) downloadLinks.push({ resolution, links });
    });
    const mInfo = $('.m-info'), thumb = mInfo.find('img.mli-thumb').attr('src') || '', metadata = parseMInfo($, mInfo), sinopsis = mInfo.find('.mli-desc').text().trim(), recommendations = [];
    $('.rekom .ml-item-rekom').each((_, el) => {
      const $el = $(el), mask = $el.find('a.ml-mask'), recLink = mask.attr('href') || '', recTitle = mask.attr('title') || $el.find('.judul').text().trim(), recThumb = $el.find('img.mli-thumb').attr('src') || '', recRating = $el.find('.mli-mvi').text().trim();
      recommendations.push({ title: recTitle, link: recLink, slug: recLink.split('/').filter(Boolean).pop(), thumb: recThumb, rating: normalizeRating(recRating) });
    });
    return { title, thumb, ...metadata, sinopsis, streamUrl: streamUrl.startsWith('//') ? 'https:' + streamUrl : streamUrl, streamOptions, downloadLinks, recommendations };
  } catch (error) { throw error; }
}

async function scrapeSeriesDetail(slug) {
  try {
    const url = `${BASE_URL}/series/${slug}/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), mInfo = $('.m-info'), title = $('.list-title').first().find('h2').text().replace(/.*?\s/, '').trim(), thumb = mInfo.find('img.mli-thumb').attr('src') || '', followedCount = $('#follows').text().replace('Followed', '').trim(), metadata = parseMInfo($, mInfo), sinopsis = $('.mli-desc').text().trim(), episodes = [];
    $('.tvseason .les-content a').each((_, el) => { episodes.push({ title: $(el).text().trim(), link: $(el).attr('href'), slug: $(el).attr('href').split('/').filter(Boolean).pop() }); });
    let trailerUrl = $('.youtube_id iframe').attr('src') || '';
    if (trailerUrl.startsWith('//')) trailerUrl = 'https:' + trailerUrl;
    const youtubeId = trailerUrl ? trailerUrl.split('/').pop().split('?')[0] : '', recommendations = [];
    $('.rekom .ml-item-rekom').each((_, el) => {
      const $el = $(el), mask = $el.find('a.ml-mask'), recLink = mask.attr('href') || '', recTitle = mask.attr('title') || $el.find('.judul').text().trim(), recThumb = $el.find('img.mli-thumb').attr('src') || '', recRating = $el.find('.mli-mvi').text().trim();
      recommendations.push({ title: recTitle, link: recLink, slug: recLink.split('/').filter(Boolean).pop(), thumb: recThumb, rating: normalizeRating(recRating) });
    });
    return { title, thumb, followedCount, ...metadata, sinopsis, trailer: youtubeId ? `https://www.youtube.com/watch?v=${youtubeId}` : null, episodes, recommendations };
  } catch (error) { throw error; }
}

async function scrapeSeriesWatch(slug) {
  try {
    const url = `${BASE_URL}/${slug}/`;
    const { data } = await axios.get(url, { headers: getHeaders(`${BASE_URL}/series/${slug.split('-episode')[0]}/`) });
    const $ = cheerio.load(data), title = $('.list-title').first().find('h2').text().replace(/.*?\s/, '').trim();
    let streamUrl = $('.pframe iframe').attr('src') || $('.movieplay iframe').attr('src') || $('#gsmtplay iframe').attr('src') || $('.tab-content iframe').attr('src') || '';
    if (!streamUrl) { $('iframe').each((_, el) => { const src = $(el).attr('src'); if (src && (src.includes('blogger.com') || src.includes('ok.ru') || src.includes('google.com') || src.includes('vidhide'))) { streamUrl = src; return false; } }); }
    const streamOptions = [];
    $('.player-modes .dropdown').each((_, drop) => {
      const label = $(drop).find('button').text().trim(), servers = [];
      $(drop).find('.dropdown-item .east_player_option').each((_, opt) => { servers.push({ name: $(opt).text().trim(), post: $(opt).attr('data-post'), nume: $(opt).attr('data-nume'), type: $(opt).attr('data-type') }); });
      if (label && servers.length > 0) streamOptions.push({ label, servers });
    });
    if (!streamUrl && streamOptions.length > 0) {
      const firstServer = streamOptions[0].servers[0];
      if (firstServer) {
        try {
          const { data: ajaxData } = await axios.post(`${BASE_URL}/wp-admin/admin-ajax.php`, qs.stringify({ action: 'player_ajax', post: firstServer.post, nume: firstServer.nume, type: firstServer.type }), { headers: { ...getHeaders(url), 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'x-requested-with': 'XMLHttpRequest' } });
          const $ajax = cheerio.load(ajaxData); streamUrl = $ajax('iframe').attr('src') || '';
        } catch (e) {}
      }
    }
    const downloadLinks = [];
    $('.download-eps ul li').each((_, li) => {
      const resolution = $(li).find('strong').text().trim() || 'Download', links = [];
      $(li).find('span a').each((_, a) => { links.push({ platform: $(a).text().trim(), link: $(a).attr('href') }); });
      if (links.length > 0) downloadLinks.push({ resolution, links });
    });
    const prevEpisode = $('.naveps .nvs').first().find('a').attr('href'), nextEpisode = $('.naveps .nvs.rght').find('a').attr('href'), allEpisodes = $('.naveps .nvsc a').attr('href');
    const episodeList = [];
    $('.dropdownEpisodeList .dropdown-menu .dropdown-item a').each((_, a) => { episodeList.push({ title: $(a).text().trim(), link: $(a).attr('href'), slug: $(a).attr('href').split('/').filter(Boolean).pop(), isActive: $(a).hasClass('active') }); });
    const mInfo = $('.m-info'), thumb = mInfo.find('img.mli-thumb').attr('src') || '', seriesTitle = mInfo.find('.judul').text().trim(), followedCount = mInfo.find('#follows').text().replace('Followed', '').trim(), metadata = parseMInfo($, mInfo), sinopsis = mInfo.find('.mli-desc').text().trim();
    return { title, seriesTitle, thumb, followedCount, ...metadata, sinopsis, streamUrl: streamUrl.startsWith('//') ? 'https:' + streamUrl : streamUrl, streamOptions, downloadLinks, navigation: { prev: prevEpisode && prevEpisode !== '#' ? prevEpisode.split('/').filter(Boolean).pop() : null, next: nextEpisode && nextEpisode !== '#' ? nextEpisode.split('/').filter(Boolean).pop() : null, all: allEpisodes ? allEpisodes.split('/').filter(Boolean).pop() : null }, episodeList };
  } catch (error) { throw error; }
}

async function scrapeGenre(slug, page = 1) {
  try {
    const url = page > 1 ? `${BASE_URL}/genre/${slug}/page/${page}/` : `${BASE_URL}/genre/${slug}/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title h2').text().trim(), items = [];
    $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); });
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeLatestAnime(page = 1) {
  try {
    const url = page > 1 ? `${BASE_URL}/anime-terbaru-animasu/page/${page}/` : `${BASE_URL}/anime-terbaru-animasu/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title h2').text().trim(), items = [];
    $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); });
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeMovieList(page = 1) {
  try {
    const url = page > 1 ? `${BASE_URL}/film/page/${page}/` : `${BASE_URL}/film/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title h2').text().trim(), items = [];
    $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); });
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeFilterAnime(query, page = 1) {
  try {
    const queryString = qs.stringify({ ...query });
    const url = page > 1 ? `${BASE_URL}/daftar-anime-2/page/${page}/?${queryString}` : `${BASE_URL}/daftar-anime-2/?${queryString}`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title h1').text().trim() || 'Filter Results', items = [];
    if ($('.movies-list .ml-item').length > 0) { $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); }); }
    else { $('.listbar .listttl a').each((_, el) => { const link = $(el).attr('href') || ''; let type = 'unknown'; if (link.includes('/anime/')) type = 'anime'; else if (link.includes('/film/')) type = 'film'; else if (link.includes('/series/')) type = 'series'; items.push({ title: $(el).text().trim(), type, link, slug: link.split('/').filter(Boolean).pop() }); }); }
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeSearch(query, page = 1) {
  try {
    const url = page > 1 ? `${BASE_URL}/page/${page}/?s=${encodeURIComponent(query)}` : `${BASE_URL}/?s=${encodeURIComponent(query)}`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = `Search Results for: ${query}`, items = [];
    $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); });
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeDonghuaList(page = 1) {
  try {
    const url = page > 1 ? `${BASE_URL}/animedonghua/page/${page}/` : `${BASE_URL}/animedonghua/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title h2').text().trim() || 'Donghua List', items = [];
    $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); });
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeOthersList(page = 1) {
  try {
    const url = page > 1 ? `${BASE_URL}/others/page/${page}/` : `${BASE_URL}/others/`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = $('.list-title h2').text().trim() || 'Others List', items = [];
    $('.movies-list .ml-item').each((_, el) => { items.push(parseLatestItem($, el)); });
    const pagination = parsePagination($);
    return { title, currentPage: parseInt(page), items, pagination };
  } catch (error) { throw error; }
}

async function scrapeAlphabeticalList() {
  try {
    const url = `${BASE_URL}/daftar-anime-2/?list`;
    const { data } = await axios.get(url, { headers: getHeaders() });
    const $ = cheerio.load(data), title = 'Daftar Anime (Alphabetical Index)', result = [];
    $('.listbar').each((_, section) => {
      const letter = $(section).find('.listabj a').text().trim(), items = [];
      $(section).find('.listttl a').each((_, el) => { const link = $(el).attr('href') || ''; items.push({ title: $(el).text().trim(), link, slug: link.split('/').filter(Boolean).pop() }); });
      if (letter && items.length > 0) result.push({ letter, items });
    });
    return { title, data: result };
  } catch (error) { throw error; }
}

module.exports = { scrapeHome, scrapeAnimeDetail, scrapeAnimeWatch, scrapeMovieWatch, scrapeSeriesDetail, scrapeSeriesWatch, scrapeGenre, scrapeLatestAnime, scrapeFilterAnime, scrapeMovieList, scrapeSearch, scrapeDonghuaList, scrapeOthersList, scrapeAlphabeticalList };